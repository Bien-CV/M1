/*
 * Created on 20 oct. 06
 *
 */
package fr.univnantes.cta;

public interface Airport {
    /**
     * @return The name of the airport.
     */
    public String getName();
}
