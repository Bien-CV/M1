#ifndef _BONJOUR_H_
#define _BONJOUR_H_

#include "langues.h"

extern void dire_bonjour(FILE *stream, const char *const nom, langue lng);

#endif // _BONJOUR_H_
