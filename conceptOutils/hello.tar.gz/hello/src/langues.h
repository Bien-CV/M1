#ifndef _LANGUES_H_
#define _LANGUES_H_

typedef enum {
  anglais,
  francais,
  neerlandais,
  allemand,
  inconnu
} langue;

#endif // _LANGUES_H_
